//+++++++++++++++++++++ Ventaja emergente ++++++++++++++++++++++++++
// Función para abrir la ventana modal
function openModal() {
    document.getElementById("modal").style.display = "block";
    document.getElementById("superponer").style.display = "block";
}

  // Función para cerrar la ventana modal
function closeModal() {
    document.getElementById("modal").style.display = "none";
    document.getElementById("superponer").style.display = "none";
}

//+++++++++++++++++++++ Menú desplegable ++++++++++++++++++++++++++
document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.getElementById('menuToggle');
    const navLinks = document.querySelector('.nav-links');

    // Abrir/cerrar menú al hacer clic en el ícono
    menuToggle.addEventListener('click', () => {
        navLinks.classList.toggle('open');
    });

    // Cerrar menú al hacer clic fuera de él
    document.addEventListener('click', (event) => {
        if (!navLinks.contains(event.target) && !menuToggle.contains(event.target)) {
            navLinks.classList.remove('open');
        }
    });
});


//+++++++++++++++++++++ Carrito de compras ++++++++++++++++++++++++++
document.addEventListener("DOMContentLoaded", () => {
    // Recuperar carrito desde LocalStorage o inicializarlo vacío
    const carrito = JSON.parse(localStorage.getItem("carrito")) || [];
    const botonesComprar = document.querySelectorAll(".comprar");
    const carritoContador = document.getElementById("Contador-carrito");
    const carritoIcono = document.querySelector(".Carrito");
    const carritoLista = document.getElementById("carrito-lista");
    const listaProductos = document.getElementById("lista-productos");
    const botonVaciarCarrito = document.getElementById("vaciar-carrito");

    // Función para actualizar la lista de productos
    const actualizarListaCarrito = () => {
        listaProductos.innerHTML = ""; // Limpia la lista
        if (carrito.length === 0) {
            const mensaje = document.createElement("li");
            mensaje.textContent = "El carrito está vacío.";
            listaProductos.appendChild(mensaje);
        } else {
            carrito.forEach(producto => {
                const li = document.createElement("li");
                li.textContent = producto;
                listaProductos.appendChild(li);
            });
        }
    };

    // Actualizar contador de productos en el carrito
    const actualizarContadorCarrito = () => {
        carritoContador.textContent = carrito.length;
    };

    // Agregar productos al carrito
    botonesComprar.forEach(boton => {
        boton.addEventListener("click", () => {
            const producto = boton.getAttribute("data-producto");
            carrito.push(producto); // Agregar producto al carrito

            // Guardar carrito actualizado en LocalStorage
            localStorage.setItem("carrito", JSON.stringify(carrito));

            actualizarContadorCarrito(); // Actualizar contador

            alert(`${producto} agregado al carrito.`); // Confirmación
        });
    });

    // Mostrar u ocultar la lista del carrito al hacer clic en el icono
    carritoIcono.addEventListener("click", () => {
        if (carritoLista.style.display === "none" || carritoLista.style.display === "") {
            actualizarListaCarrito(); // Actualiza la lista
            carritoLista.style.display = "block"; // Muestra la lista
        } else {
            carritoLista.style.display = "none"; // Oculta la lista
        }
    });

    // Cerrar la lista al hacer clic fuera del carrito
    document.addEventListener("click", (event) => {
        if (!carritoIcono.contains(event.target) && !carritoLista.contains(event.target)) {
            carritoLista.style.display = "none";
        }
    });

    // Vaciar el carrito
    botonVaciarCarrito.addEventListener("click", () => {
        carrito.length = 0; // Vacía el arreglo
        localStorage.removeItem("carrito"); // Elimina del LocalStorage
        actualizarListaCarrito(); // Actualiza la lista
        actualizarContadorCarrito(); // Actualiza el contador
        alert("El carrito ha sido vaciado.");
    });

    // Inicializar la visualización del carrito al cargar la página
    actualizarListaCarrito();
    actualizarContadorCarrito();
});


//+++++++++++++++++ Calculadora de IMC +++++++++++++++++++++++++++++++
//Capturo elementos
let barra = document.getElementById("barra");
let calcular = document.getElementById("calcular");
let reiniciar = document.getElementById("reiniciar");
let porcentaje = document.getElementById("porcentaje");
let masaCorporal = document.getElementById("imc");
let clasificacion = document.getElementById("clasificacion");

// Variables de control
let indice = 0;
let intervalo;

//Variables de calculo
let imc = 0;
let categoria = 0;
//let respuesta = "";

// Crear los 10 cuadritos
for (let i = 0; i < 10; i++) {
    let cuadrito = document.createElement("div");
    barra.appendChild(cuadrito);//Crea div dentro del div barra 
}

// Cuando se apreta calcular
calcular.onclick = function(){
    let altura = parseFloat(document.getElementById("talla").value);
    let peso = parseFloat(document.getElementById("peso").value);
    // Evitar múltiples clicks
    if (intervalo) return;

    intervalo = setInterval(function() {
        if (indice < 10) {
            // Se muestran cudritos
            barra.children[indice].style.opacity = "1";
            indice++; //indice = indice+1
            // Actualizar el porcentaje
            porcentaje.textContent = indice * 10 + "%";
            
            if(indice==10){
                imc = Math.round((peso/(altura*altura))*10)/10;
                masaCorporal.textContent = "Su indice de masa corporal es: "+imc;
                clasificacion.textContent = clasificacionIMC(imc);
            }
            
        } else {
            clearInterval(intervalo); // Detener la animación
            intervalo = null;
        }
    }, 300); // Duración total de 3 segundos
};
function clasificacionIMC(imc){
    if (imc < 18.5) {
        categoria = 1;
    } else if (imc < 24.9) {
        categoria = 2;
    } else if (imc < 29.9) {
        categoria = 3;
    } else if (imc < 34.9) {
        categoria = 4;
    } else if (imc < 39.9) {
        categoria = 5;
    } else {
        categoria = 6;
    }
    switch (categoria) {
        case 1:
            return "Clasificación: Bajo peso";
        case 2:
            return "Clasificación: Normal";
        case 3:
            return "Clasificación: Sobrepeso";
        case 4:
            return "Clasificación: Obesidad grado 1";
        case 5:
            return "Clasificación: Obesidad grado 2";
        case 6:
            return "Clasificación: Obesidad grado 3";
        default:
            return "IMC no válido";
    }
}
// Cuando se apreta reiniciar
reiniciar.onclick = function() {
    clearInterval(intervalo); // Detener cualquier animación en curso

    //Reiniciar los valores
    intervalo = null;
    indice = 0;
    porcentaje.textContent = "0%";
    masaCorporal.textContent = "";
    clasificacion.textContent = "";
    // Ocultar los cuadritos
    for (let i = 0; i < 10; i++) {
        barra.children[i].style.opacity = "0";
    }
};

//+++++++++++++++++++++Libro de reclamaciones++++++++++++++++++++++++++

//OnClick (en etiqueta)
function reclamoRegistrado(){
    let respuesta = confirm("¿Esta seguro de su reclamo?");
    if(respuesta){
        let nombre = document.getElementById("name").value;
        let apellido = document.getElementById("apellidos").value;
        alert("Reclamo registrado corrrectamente");
        [`Apreciamos sus sugerencias cliente ${nombre} ${apellido}`].forEach(alert);
    }else{
        alert("Reclamo cancelado");
    }
}

//OnChange (en etiqueta)
function seleccionarBien() {
    let bien = document.getElementById("bienRealizado").value;
    document.getElementById("informacion").innerText = `Usted seleccionó ${bien}`;
}











